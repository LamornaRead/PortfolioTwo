<?php

$host = "localhost"; 
$dbname = "lamornar_portfolio";
$username = "lamornar_lamorna";
$password = "HarryTheCat2008.";